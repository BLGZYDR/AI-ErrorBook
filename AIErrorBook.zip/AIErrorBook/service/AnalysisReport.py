import uuid
from openai import OpenAI
from modules.Question import Question
from modules.KnowledgePoint import KnowledgePoint
from modules.LearningPlan import LearningPlan

class AnalysisReport:
    def __init__(self):
        self.client = OpenAI(api_key="sk-e4e056ab6804462d8bd8a3700c85f09a", base_url="https://api.deepseek.com")
        self.reportId = str(uuid.uuid4())
        self.weakKnowledgePoints = []
        self.learningPlan = None

    def identifyWeakPoints(self, questions: list) -> list:
        all_kps = {}
        for q in questions:
            for kp in q.knowledgepoint + q.relatedknowledgepoint:
                all_kps[kp.title] = kp
        all_kps = list(all_kps.values())

        prompt = "分析以下错题，从给定知识点中选择最需要加强的5个，直接返回标题（用逗号分隔）：\n知识点列表：\n"
        prompt += "\n".join([f"- {kp.title}: {kp.description}" for kp in all_kps])
        prompt += "\n\n错题信息：\n"
        
        for idx, q in enumerate(questions, 1):
            prompt += f"\n题目{idx}：\n内容：{q.content}\n错误原因：{q.errorReason}\n"
            prompt += f"关联知识点：{', '.join([kp.title for kp in q.knowledgepoint])}\n"
            prompt += f"相关知识点：{', '.join([kp.title for kp in q.relatedknowledgepoint])}"

        response = self.client.chat.completions.create(
            model="deepseek-chat",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=512
        )
        
        titles = [t.strip() for t in response.choices[0].message.content.split(",")]
        self.weakKnowledgePoints = [kp for kp in all_kps if kp.title in titles]
        return self.weakKnowledgePoints

    def generateLearningPlan(self, weakKPs: list) -> LearningPlan:
        prompt = "根据以下薄弱知识点生成学习计划：\n"
        for kp in weakKPs:
            prompt += f"- {kp.title}: {kp.description}\n"
        prompt += "\n请按照以下格式返回：\n标题：<标题>\n建议：\n1. <建议1>\n2. <建议2>\n每日任务：\n- <任务1>\n- <任务2>"

        response = self.client.chat.completions.create(
            model="deepseek-chat",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=512
        )
        
        content = response.choices[0].message.content
        lines = [line.strip() for line in content.split("\n")]
        
        title = lines[0].split("：", 1)[1]
        suggestions = []
        daily_tasks = []
        current_section = None
        
        for line in lines[1:]:
            if line.startswith("建议：") or line.startswith("建议:"):
                current_section = "suggestions"
            elif line.startswith("每日任务：") or line.startswith("每日任务:"):
                current_section = "tasks"
            elif line.startswith(("1.", "2.", "3.")) and current_section == "suggestions":
                clean_line = line.split(". ", 1)[1] if ". " in line else line[2:]
                suggestions.append(clean_line)
            elif line.startswith("-") and current_section == "tasks":
                daily_tasks.append(line[1:].strip())
            # 处理无项目符号的任务行
            elif current_section == "tasks" and line:
                daily_tasks.append(line)
        
        self.learningPlan = LearningPlan(title, suggestions, daily_tasks)
        return self.learningPlan
