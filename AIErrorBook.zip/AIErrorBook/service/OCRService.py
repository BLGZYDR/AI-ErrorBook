import base64
import os
import json
import hashlib
import re
import ast
from openai import OpenAI
from volcenginesdkarkruntime import Ark
from pathlib import Path
from modules.KnowledgePoint import KnowledgePoint
from modules.Question import Question
from io import BytesIO
from PIL import Image


# OCR服务类
class OCRService:
    # 类常量 - API密钥（实际使用时替换为您的真实密钥）
    DOUBAN_API_KEY = "bbbbb5a6-0f1d-4842-bd6e-b6909c321e4b"
    DEEPSEEK_API_KEY = "sk-e4e056ab6804462d8bd8a3700c85f09a"
    
    # 模型ID
    DOUBAN_MODEL_ID = "doubao-1.5-vision-lite-250315"
    DEEPSEEK_MODEL = "deepseek-chat"
    
    # 支持的科目列表
    SUPPORTED_SUBJECTS = ["数学", "物理", "化学", "生物", "英语", "语文", "历史", "地理", "政治"]
    
    def __init__(self):
        """初始化OCR服务（API密钥已在类中定义）"""
        # 初始化豆包客户端
        self.douban_client = Ark(api_key=self.DOUBAN_API_KEY)
        
        # 初始化DeepSeek客户端
        self.deepseek_client = OpenAI(
            api_key=self.DEEPSEEK_API_KEY,
            base_url="https://api.deepseek.com"
        )
    
    def _encode_image(self, image_file):
        """将图像文件编码为带MIME类型的base64字符串，自动转换不支持的格式"""
        # 读取图片数据
        img_data = image_file.read()
        
        # 验证图片格式
        try:
            img = Image.open(BytesIO(img_data))
            format = img.format
        except Exception as e:
            raise ValueError(f"无法识别的图片格式: {e}")
        
        # 支持格式映射
        SUPPORTED_FORMATS = ['JPEG', 'PNG', 'WEBP']
        MIME_MAP = {
            'JPEG': 'jpeg',
            'JPG': 'jpeg',
            'PNG': 'png',
            'WEBP': 'webp'
        }
        
        # 转换不支持的格式
        if format not in SUPPORTED_FORMATS:
            # 转换为最通用的JPEG格式
            output_buffer = BytesIO()
            img.convert("RGB").save(output_buffer, format="JPEG", quality=95)
            img_data = output_buffer.getvalue()
            mime_type = "jpeg"
            print(f"警告：已转换不支持的格式 {format} 为 JPEG")
        else:
            mime_type = MIME_MAP.get(format.upper(), "jpeg")
        
        # 编码为base64
        base64_data = base64.b64encode(img_data).decode('utf-8')
        return f"data:image/{mime_type};base64,{base64_data}"
    
    def recognize(self, image_file):
        """
        使用豆包API识别图片中的文字
        :param image_file: 图像文件对象
        :return: 识别出的文本字符串
        """
        # 编码图像
        base64_image = self._encode_image(image_file)
        
        # 调用豆包API
        response = self.douban_client.chat.completions.create(
            model=self.DOUBAN_MODEL_ID,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "image_url", "image_url": {"url": base64_image}},
                        {"type": "text", "text": "请精确识别图片中的所有文字内容，包括题目、选项、答案和解析。确保保留题号、公式和表格结构。"}
                    ],
                }
            ],
        )
        
        # 返回识别结果
        return response.choices[0].message.content
    
    def _generate_kp_id(self, title):
        """为知识点生成唯一ID（基于标题的哈希）"""
        return hashlib.md5(title.encode()).hexdigest()[:8]
    
    def _parse_questions_from_response(self, response_data):
        """
        从DeepSeek API响应中解析问题列表
        :param response_data: API返回的JSON数据
        :return: Question对象列表
        """
        questions = []
        
        # 确保响应是有效的JSON
        if not isinstance(response_data, dict):
            try:
                response_data = json.loads(response_data)
            except json.JSONDecodeError:
                # 尝试使用ast.literal_eval作为备选方案
                try:
                    response_data = ast.literal_eval(response_data)
                except:
                    return []
        
        # 提取问题列表
        questions_data = response_data.get("questions", [])
        
        # 处理单个问题对象的情况
        if isinstance(questions_data, dict):
            questions_data = [questions_data]
        
        for idx, q_data in enumerate(questions_data):
            # 生成题目ID（如果API未提供）
            question_id = q_data.get("questionId", f"Q{idx+1}")
            
            # 创建Question对象
            question = Question(
                subject=q_data.get("subject", "未知科目"),
                questionId=question_id,
                content=q_data.get("content", ""),
                userAnswer=q_data.get("userAnswer", ""),
                correctAnswer=q_data.get("correctAnswer", ""),
                errorReason=q_data.get("errorReason", "")
            )
            
            # 处理知识点
            knowledge_points = []
            kp_list = q_data.get("knowledgepoint", [])
            
            # 处理单个知识点对象的情况
            if isinstance(kp_list, dict):
                kp_list = [kp_list]
                
            for kp in kp_list:
                title = kp.get("title", "")
                if title:  # 确保有标题才添加
                    kp_id = self._generate_kp_id(title)
                    knowledge_points.append(
                        KnowledgePoint(kp_id, title, kp.get("description", ""))
                    )
            question.updateKnowledgePoint(knowledge_points)
            
            # 处理相关知识点
            related_points = []
            rkp_list = q_data.get("relatedknowledgepoint", [])
            
            # 处理单个相关知识点对象的情况
            if isinstance(rkp_list, dict):
                rkp_list = [rkp_list]
                
            for rkp in rkp_list:
                title = rkp.get("title", "")
                if title:  # 确保有标题才添加
                    rkp_id = self._generate_kp_id(title)
                    related_points.append(
                        KnowledgePoint(rkp_id, title, rkp.get("description", ""))
                    )
            question.updateRelatedKnowledgePoint(related_points)
            
            questions.append(question)
        
        return questions
    
    def getQuestions(self, recognize_result, subject=None):
        """
        使用DeepSeek API将识别结果解析为问题列表
        :param recognize_result: 从recognize方法获取的文本
        :param subject: 用户指定的科目（可选）
        :return: Question对象列表
        """
        # 构造通用提示词，支持所有题型
        system_prompt = """
        你是一个智能错题分析专家，需要从OCR识别文本中提取错题信息。请严格按照以下要求处理：
        
        1. 输出格式必须是有效的JSON对象，包含"questions"字段，值为问题对象数组
        2. 每个问题对象包含以下字段:
           - subject: 科目(如"数学","物理")
           - questionId: 题目唯一标识(如"Q1")
           - content: 题目完整内容（包括题干和所有选项，如果是大题则包括所有小问）
           - userAnswer: 学生填写的答案（如果有的话）
           - correctAnswer: 详细的解题步骤以及正确答案（必须包含完整的计算过程和推导步骤）
           - errorReason: 错因分析（如果学生答案存在且错误）
           - knowledgepoint: 本题知识点数组, 每个元素包含{title, description}
           - relatedknowledgepoint: 相关知识点数组, 每个元素包含{title, description}
        
        3. 题目类型处理规则:
           a) 选择题: 
               - 从文本中识别出学生选择的答案，填入userAnswer
               - 根据题目内容分析出正确答案，填入correctAnswer
           b) 填空题: 
               - 识别学生填写的答案，填入userAnswer
               - 分析正确答案，填入correctAnswer
           c) 大题（计算题、解答题）:
               - 如果题目中包含学生填写的答案，则提取并填入userAnswer
               - correctAnswer填入具体的解题步骤和标准答案
               - 如果学生答案与标准答案不一致，提供errorReason
        
        4. 特别强调：对于大题（计算题、解答题），correctAnswer必须包含：
           - 完整的公式推导
           - 具体的数值计算过程
           - 每一步的中间结果
           - 最终答案
           禁止使用"需要详细展开"、"具体计算过程较为复杂"等模糊表述，必须实际完成计算。
           
        5. 题目结构识别指南:
           - 题号: 如"5、"、"1."、"14."等开头
           - 题干: 问题描述部分
           - 选项（选择题）: 以A、B、C、D开头，每个选项单独一行或以分号分隔
           - 表格数据: 保留表格结构，用|分隔列
        
        6. 知识点描述应清晰且简明(不低于20字，不超过50字)
        
        7. 示例1（选择题）:
           输入文本: 
                "5、已知a∥α，b⊂α，则直线a与直线b的位置关系是（ ）
                A、平行；
                B、相交或异面；
                C、异面；
                D、平行或异面。
                答案：D"
           输出格式:
            {
              "questions": [
                {
                  "subject": "数学",
                  "questionId": "Q1",
                  "content": "5、已知a∥α，b⊂α，则直线a与直线b的位置关系是（ ）\nA、平行；\nB、相交或异面；\nC、异面；\nD、平行或异面。",
                  "userAnswer": "D",
                  "correctAnswer": "D",
                  "errorReason": "",
                  "knowledgepoint": [
                    {"title": "空间直线与平面的位置关系", "description": "直线与平面平行时，直线与平面内直线的位置关系"}
                  ],
                  "relatedknowledgepoint": [
                    {"title": "空间几何", "description": "空间中点、线、面的位置关系"}
                  ]
                }
              ]
            }
        
        8. 示例2（大题）展示完整的解题步骤:
           输入文本:
                "18. 用三点公式求f(x)=1/(1+x)^2在x=1.0，1.1和1.2处的导数值，并估计误差。
                f(x)的值由下表给出：
                | x   | 1.0  | 1.1  | 1.2  |
                | f(x) | 0.2500 | 0.2268 | 0.2066 |"
           输出格式:
            {
              "questions": [
                {
                  "subject": "数学",
                  "questionId": "Q1",
                  "content": "18. 用三点公式求 f (x)=1/(1+x)^2 在 x=1.0，1.1 和 1.2 处的导数值，并估计误差。\nf (x) 的值由下表给出：\n| x | 1.0 | 1.1 | 1.2 |\n| f (x) | 0.2500 | 0.2268 | 0.2066 |",
                  "userAnswer": "",
                  "correctAnswer": "计算过程如下：\n1. 确定步长 h = 1.1 - 1.0 = 0.1\n\n2. 计算 x=1.0 处的导数（左端点公式）：\n   f'(x₀) ≈ [-3f(x₀) + 4f(x₁) - f(x₂)] / (2h)\n   = [-3×0.2500 + 4×0.2268 - 0.2066] / (2×0.1)\n   = [-0.7500 + 0.9072 - 0.2066] / 0.2\n   = [-0.0494] / 0.2\n   = -0.247\n\n3. 计算 x=1.1 处的导数（中点公式）：\n   f'(x₁) ≈ [f(x₂) - f(x₀)] / (2h)\n   = [0.2066 - 0.2500] / (2×0.1)\n   = [-0.0434] / 0.2\n   = -0.217\n\n4. 计算 x=1.2 处的导数（右端点公式）：\n   f'(x₂) ≈ [f(x₀) - 4f(x₁) + 3f(x₂)] / (2h)\n   = [0.2500 - 4×0.2268 + 3×0.2066] / 0.2\n   = [0.2500 - 0.9072 + 0.6198] / 0.2\n   = [-0.0374] / 0.2\n   = -0.187\n\n5. 误差估计：\n   三点公式的截断误差为 O(h²) = (0.1)² = 0.01\n   实际误差可通过泰勒展开分析得到具体表达式",
                  "errorReason": "",
                  "knowledgepoint": [
                    {"title": "数值微分", "description": "利用函数在一些离散点的值来近似计算导数"}
                  ],
                  "relatedknowledgepoint": [
                    {"title": "三点公式", "description": "利用三个相邻点的函数值计算导数的公式，包括中点公式和端点公式"}
                  ]
                }
              ]
            }
           
        9. 示例3（微积分题展示完整步骤）:
           输入文本: "计算二重积分∫∫_D e^{y-x} dydx, 其中D=[0,0.5]×[0,0.5]"
           输出格式:
            {
              "questions": [
                {
                  "subject": "数学",
                  "questionId": "Q1",
                  "content": "计算二重积分∫∫_D e^{y-x} dydx, 其中D=[0,0.5]×[0,0.5]",
                  "userAnswer": "",
                  "correctAnswer": "计算步骤：\n1. 先对y积分：\n   ∫_0^{0.5} e^{y-x} dy = e^{-x} ∫_0^{0.5} e^y dy\n   = e^{-x} [e^y]_0^{0.5}\n   = e^{-x} (e^{0.5} - e^0)\n   = e^{-x} (√e - 1)\n\n2. 再对x积分：\n   ∫_0^{0.5} e^{-x}(√e - 1) dx\n   = (√e - 1) ∫_0^{0.5} e^{-x} dx\n   = (√e - 1) [-e^{-x}]_0^{0.5}\n   = (√e - 1) [-e^{-0.5} - (-e^0)]\n   = (√e - 1)(-1/√e + 1)\n   = (√e - 1)(1 - 1/√e)\n   = (√e - 1)^2 / √e\n\n3. 数值计算：\n   √e ≈ 1.6487\n   (1.6487 - 1)^2 / 1.6487 ≈ (0.6487)^2 / 1.6487 ≈ 0.4209 / 1.6487 ≈ 0.2553",
                  "errorReason": "",
                  "knowledgepoint": [
                    {"title": "二重积分", "description": "对二元函数在平面区域上的积分"}
                  ],
                  "relatedknowledgepoint": [
                    {"title": "累次积分", "description": "将多重积分转化为多次单变量积分的方法"}
                  ]
                }
              ]
            }
         
        10. 示例3（填空题）:
           输入文本:三点公式中，中心差分公式用于计算函数在中间点的导数值，其公式为 f’(x₁)≈[f (x₂)-f (x₀)]/(___) + O (h²)，请填空。
           输出格式:
            {
                "questions": [
                {
                 "subject": "数学",
                 "questionId": "T1",
                 "content": "三点公式中，中心差分公式用于计算函数在中间点的导数值，其公式为 f’(x₁)≈[f (x₂)-f (x₀)]/(___) + O (h²)，请填空。",
                 "userAnswer": "",
                 "correctAnswer": "2h",
                 "errorReason": "",
                 "knowledgepoint": [
                    {"title": "数值微分", "description": "利用函数在一些离散点的值来近似计算导数"}
                 ],
                 "relatedknowledgepoint": [
                    {"title": "三点公式", "description": "利用三个相邻点的函数值计算导数的公式，包括前向、后向、中心差分公式"}
                 ]
                }
               ]
            }
            
        11. 特殊处理:
           - 对于包含多个小题的大题，拆分为多个问题对象
           - 保留所有数学公式和符号
           - 表格数据保持原样
        12. 注意事项：
           - 大题的正确答案计算过程要详细（如示例2和示例3），计算步骤不能省略，如何得到结果要有详细的过程
           - 对于理科题目要有完整的计算过程或逻辑论证，对于文科题目要有详细的推理过程
        """
        
        # 如果用户指定了科目，则添加到系统提示词
        if subject and subject in self.SUPPORTED_SUBJECTS:
            system_prompt += f"\n\n重要提示：用户已指定科目为 '{subject}'，所有题目的subject字段必须使用此科目值！"
        
        # 在用户消息中添加科目信息（如果指定）
        user_message = recognize_result
        if subject and subject in self.SUPPORTED_SUBJECTS:
            user_message = f"科目：{subject}\n" + user_message
        
        # 调用DeepSeek API
        try:
            response = self.deepseek_client.chat.completions.create(
                model=self.DEEPSEEK_MODEL,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message}
                ],
                response_format={"type": "json_object"},
                temperature=0.1,  # 降低随机性，提高准确性
                max_tokens=4096
            )
            
            # 获取并解析响应
            result_json = response.choices[0].message.content
            
            # 调试用：打印API返回的原始JSON字符串
            #print("DeepSeek API返回的原始JSON字符串:")
            #print(result_json)
            
            # 尝试解析JSON
            try:
                # 先尝试标准JSON解析
                parsed_data = json.loads(result_json)
            except json.JSONDecodeError:
                try:
                    # 尝试使用ast.literal_eval作为备选方案
                    parsed_data = ast.literal_eval(result_json)
                except Exception as e:
                    print(f"JSON解析失败: {e}")
                    return []
            
            # 解析问题
            questions = self._parse_questions_from_response(parsed_data)
            return questions
        except Exception as e:
            print(f"调用DeepSeek API时出错: {e}")
            import traceback
            traceback.print_exc()
            return []

