from typing import List
from openai import OpenAI
from modules.KnowledgePoint import KnowledgePoint
from modules.Exercise import Exercise

class ExerciseRecommender:
    def __init__(self):
        self.client = OpenAI(
            api_key="sk-e4e056ab6804462d8bd8a3700c85f09a",
            base_url="https://api.deepseek.com"
        )
    
    def recommendExercises(self, kps: List[KnowledgePoint]) -> List[Exercise]:
        # 构建提示信息，包含所有知识点
        prompt = self._build_prompt(kps)
        
        # 调用DeepSeek API
        response = self._call_api(prompt)
        
        # 解析API返回结果，转换为Exercise列表
        exercises = self._parse_response(response, kps)
        
        return exercises
    
    def _build_prompt(self, kps: List[KnowledgePoint]) -> str:
        """构建向DeepSeek请求的提示信息"""
        prompt = "请根据以下知识点生成相关练习题：\n\n"
        for kp in kps:
            prompt += f"{kp.show_details()}\n\n"
        
        prompt += """
生成要求：
1. 每个知识点生成2-3道练习题
2. 每道题包含题目内容、难度等级(1-5星)和正确答案
3. 输出格式：
[
  {
    "exerciseId": 1,
    "content": "题目内容",
    "difficulty": 3,
    "correctAnswer": "正确答案"
  },
  ...
]
"""
        return prompt
    
    def _call_api(self, prompt: str) -> str:
        """调用DeepSeek API并返回响应内容"""
        try:
            response = self.client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {"role": "system", "content": "You are an educational expert capable of generating high-quality exercises for given knowledge points."},
                    {"role": "user", "content": prompt}
                ],
                stream=False
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"API调用出错: {e}")
            # 实际应用中应该有更完善的错误处理
            return "[]"
    
    def _parse_response(self, response: str, kps: List[KnowledgePoint]) -> List[Exercise]:
        """解析API返回的JSON字符串并转换为Exercise对象列表"""
        import json
        
        try:
            exercises_data = json.loads(response)
            exercises = []
            
            # 为每个练习题分配唯一ID
            for i, data in enumerate(exercises_data):
                # 确保数据包含所有必要字段
                if all(key in data for key in ['content', 'difficulty', 'correctAnswer']):
                    exercise_id = data.get('exerciseId', i + 1)
                    content = data['content']
                    difficulty = min(max(data['difficulty'], 1), 5)  # 确保难度在1-5之间
                    correct_answer = data['correctAnswer']
                    
                    exercises.append(Exercise(
                        exerciseId=exercise_id,
                        content=content,
                        difficulty=difficulty,
                        correctAnswer=correct_answer
                    ))
            
            return exercises
        except json.JSONDecodeError:
            print("无法解析API响应，返回空列表")
            return []

