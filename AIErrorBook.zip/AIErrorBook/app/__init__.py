from flask import Flask, request, session, redirect

def auth():
    if request.path in ['/LoginRegisterView.html', '/register', '/login']:
        return
    
    username = session.get('username')
    if username:
        return
    
    return redirect('/LoginRegisterView.html')



def create_app():
    app = Flask(__name__)
    app.secret_key = "123456"

    #注册页面跳转蓝图
    from .views import page_jump
    app.register_blueprint(page_jump.pj)

    #注册账户管理蓝图
    from .views import account
    app.register_blueprint(account.ac)

    #注册题目管理蓝图
    from .views import question_control
    app.register_blueprint(question_control.qc)

    #注册学习计划管理蓝图
    from .views import learningplan_control
    app.register_blueprint(learningplan_control.lc)

    #注册推荐题目管理蓝图
    from .views import exercise_control
    app.register_blueprint(exercise_control.ec)

    #拦截器
    app.before_request(auth)

    return app