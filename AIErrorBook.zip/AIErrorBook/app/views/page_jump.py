from flask import Blueprint, render_template

pj = Blueprint("page", __name__)

# 处理根路径的路由
@pj.route('/', methods=['GET'])
def index():
    return render_template('LoginRegisterView.html')

# 提供 LoginRegisterView.html
@pj.route('/LoginRegisterView.html', methods=['GET'])
def login_register_view():
    return render_template('LoginRegisterView.html')

# 提供 MainView.html
@pj.route('/MainView.html', methods=['GET'])
def main_view():
    return render_template('MainView.html')

# 提供 UploadView.html
@pj.route('/UploadView.html', methods=['GET'])
def upload_view():
    return render_template('UploadView.html')

# 提供 ErrorBookView.html
@pj.route('/ErrorBookView.html', methods=['GET'])
def error_book_view():
    return render_template('ErrorBookView.html')

# 提供 SettingsView.html
@pj.route('/SettingsView.html', methods=['GET'])
def settings_view():
    return render_template('SettingsView.html')

# 提供 RecommendationView.html
@pj.route('/RecommendationView.html', methods=['GET'])
def recommendation_view():
    return render_template('RecommendationView.html')

# 提供 SingleQuestionDetailView.html
@pj.route('/SingleQuestionDetailView.html', methods=['GET'])
def single_question_detail_view():
    return render_template('SingleQuestionDetailView.html')

# 提供 ComprehensiveAnalysisView.html
@pj.route('/ComprehensiveAnalysisView.html', methods=['GET'])
def comprehensive_analysis_view():
    return render_template('ComprehensiveAnalysisView.html')