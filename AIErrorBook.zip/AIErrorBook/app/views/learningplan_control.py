from flask import Flask, request, jsonify, session, Blueprint
import hashlib
import service.AnalysisReport
from utils import db
from modules.Question import Question
from modules.KnowledgePoint import KnowledgePoint
from modules.LearningPlan import LearningPlan
from service.AnalysisReport import AnalysisReport
import json
import traceback

lc = Blueprint("learningplan_control", __name__)

#学习计划查看接口
@lc.route('/learningplan_check', methods=['POST'])
def learningplan_check():
    try:
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'message': '用户未登录'}), 401
            
        plan = db.fecth_one(
            "SELECT title, suggestions, daily_task FROM learningplan WHERE user_id = %s",
            (user_id,))
        if not plan:
            return jsonify({'message': '无学习计划记录,请点击更新按钮'}), 404
        
        # 使用json替代eval
        return jsonify({
            "title": plan[0],
            "suggestions": json.loads(plan[1]), 
            "daily_tasks": json.loads(plan[2])
        })
    except Exception as err:
        # 添加详细错误日志
        traceback.print_exc()
        return jsonify({'message': f'加载失败: {str(err)}'}), 500



#学习计划更新接口
@lc.route('/learningplan_update', methods=['POST'])
def learningplan_update():
    try:
        user_id = session['user_id']
        
        # 从数据库获取当前用户的所有错题
        questions = db.fecth_all("SELECT id, content, userAnswer, correctAnswer, errorReason, subject_name FROM question WHERE user_id = %s", (user_id,))
        question_list = []
        
        # 构建Question对象列表
        for q in questions:
            q_id, content, user_answer, correct_answer, error_reason, subject = q
            
            # 获取本题知识点
            kps = db.fecth_all(
                "SELECT title, description FROM knowledgepoint WHERE question_id = %s AND knowledgepoint_type = 'itself'",
                (q_id,)
            )
            knowledgepoint_list = [KnowledgePoint(None, kp[0], kp[1]) for kp in kps]
            
            # 获取相关知识点
            related_kps = db.fecth_all(
                "SELECT title, description FROM knowledgepoint WHERE question_id = %s AND knowledgepoint_type = 'related'",
                (q_id,)
            )
            relatedknowledgepoint_list = [KnowledgePoint(None, kp[0], kp[1]) for kp in related_kps]
            
            # 创建Question对象
            question = Question(
                subject=subject,
                questionId=q_id,
                content=content,
                userAnswer=user_answer,
                correctAnswer=correct_answer,
                errorReason=error_reason
            )
            question.updateKnowledgePoint(knowledgepoint_list)
            question.updateRelatedKnowledgePoint(relatedknowledgepoint_list)
            question_list.append(question)
        
        # 生成新的学习计划
        analysis_report = AnalysisReport()  
        weak_kps = analysis_report.identifyWeakPoints(question_list)
        new_learning_plan = analysis_report.generateLearningPlan(weak_kps)

        suggestions = json.dumps(new_learning_plan.suggestions)
        daily_tasks = json.dumps(new_learning_plan.daily_tasks)
        
        # 更新数据库中的学习计划
        db.execute(
            """
            INSERT INTO learningplan (user_id, title, suggestions, daily_task)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                title = VALUES(title),
                suggestions = VALUES(suggestions),
                daily_task = VALUES(daily_task)
            """,
            (user_id, new_learning_plan.title, suggestions, daily_tasks)
        )
        
        # 返回更新后的数据
        updated_plan = db.fecth_one("SELECT title, suggestions, daily_task FROM learningplan WHERE user_id = %s", (user_id,))
        if not updated_plan:
            return jsonify({'message': '更新失败'}), 500
            
        return jsonify({
            "title": updated_plan[0],
            "suggestions": json.loads(updated_plan[1]),
            "daily_tasks": json.loads(updated_plan[2])
        })
        
    except Exception as err:
        traceback.print_exc()
        return jsonify({'message': f'更新失败: {str(err)}'}), 500
        
