from flask import Flask, request, jsonify, session, Blueprint
import mysql.connector
import hashlib
from service.ExerciseRecommender import ExerciseRecommender
from utils import db
from modules.KnowledgePoint import KnowledgePoint

ec = Blueprint("exercise_control", __name__)

# 练习推荐接口
@ec.route('/exercise_recommend', methods=['POST'])
def exercise_recommend():
    data = request.get_json()
    question_id = data.get("question_id")
    exerciseRecommender = ExerciseRecommender()
    try:
        # 获取当前题目的知识点
        knowledgepoints = db.fecth_all(
            "SELECT id, title, description FROM knowledgepoint WHERE question_id = %s AND knowledgepoint_type = %s",
            (question_id, "itself")
        )
        
        knowledgepoint_list = []
        for (id, title, description) in knowledgepoints:
            knowledgepoint_list.append(KnowledgePoint(id, title, description))
        
        # 获取推荐练习题
        exercise_list = exerciseRecommender.recommendExercises(knowledgepoint_list)
        
        # 转换为字典列表返回
        exercises_json = []
        for exercise in exercise_list:
            exercises_json.append({
                'exerciseId': exercise.exerciseId,
                'content': exercise.content,
                'difficulty': exercise.difficulty,
                'correctAnswer': exercise.correctAnswer
            })
            
        return jsonify(exercises_json)
        
    except mysql.connector.Error as err:
        return jsonify({'message': f'数据库错误: {err}'}), 500
    
    

