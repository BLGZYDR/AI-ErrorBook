from flask import Flask, request, jsonify, session, Blueprint
import hashlib
from service.OCRService import OCRService
from utils import db

qc = Blueprint("question_control", __name__)


# 上传接口
@qc.route('/upload', methods=['POST'])
def upload():
    # 从前端获取文件和学科
    fileList = request.files.getlist('fileList')
    subject_name = request.form.get('subject_name')

    user_id = session['user_id']

    ocrservice=OCRService()

    for file in fileList:
        #OCR识别
        recognize_result = ocrservice.recognize(file)
        if not recognize_result:
            return jsonify({'message': '未识别到文字，请重新上传清晰图片'}), 400
        
        question_list = ocrservice.getQuestions(recognize_result,subject_name)
        if not question_list:
            return jsonify({'message': '未分析到题目，请重新上传清晰图片'}), 400
        
        for question in question_list:
            
            # 上传新题目
            db.execute(
                "INSERT INTO question (content,userAnswer,correctAnswer,errorReason,subject_name,user_id) VALUES (%s, %s, %s, %s, %s, %s)", 
                (question.content, question.userAnswer, question.correctAnswer, question.errorReason, subject_name, user_id)
            )
            
            #获取问题id
            question_id_result = db.fecth_one("select id from question where content=%s", (question.content,))
            if not question_id_result:
                return jsonify({'message': '无法获取问题 ID'}), 400
            question_id = question_id_result[0]

            # 上传本身知识点
            for knowlegdepoint in question.knowledgepoint:
                db.execute(
                    "INSERT INTO knowledgepoint (title,description,question_id,knowledgepoint_type) VALUES (%s, %s, %s,%s)", 
                    (knowlegdepoint.title, knowlegdepoint.description, question_id, "itself")
                )

            # 上传拓展知识点
            for relatedknowlegdepoint in question.relatedknowledgepoint:
                db.execute(
                    "INSERT INTO knowledgepoint (title,description,question_id,knowledgepoint_type) VALUES (%s, %s, %s, %s)", 
                    (relatedknowlegdepoint.title, relatedknowlegdepoint.description, question_id, "related")
                )

    return jsonify({'message': '上传成功'}), 201
    

# 错题列表查看接口
@qc.route('/checkquestion_total', methods=['POST'])
def checkquestion_total():
    user_id = session['user_id']
    subject_name = request.form.get('subject_name')
    
    # 根据是否有学科参数构建不同的查询
    if subject_name:
        questions = db.fecth_all("SELECT id, content FROM question WHERE user_id = %s AND subject_name = %s", (user_id, subject_name))
    else:
        questions = db.fecth_all("SELECT id, content FROM question WHERE user_id = %s", (user_id,))
    
    question_list = []
    for question in questions:
        question_list.append({
            'id': question[0],
            'content': question[1]
        })
    return jsonify(question_list), 200



# 单道错题查看接口
@qc.route('/checkquestion_singal', methods=['POST'])
def checkquestion_singal():

    # 1. 获取参数并校验
    data = request.get_json()
    question_id = data.get("question_id")
    if not question_id:
        return jsonify({'message': '缺少必需参数question_id'}), 400

    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'message': '用户未登录'}), 401

    # 2. 查询题目基础信息
    question = db.fecth_one(
        "SELECT content, userAnswer, correctAnswer, errorReason FROM question WHERE id = %s AND user_id = %s",
        (question_id, user_id)
    )
    if not question:
        return jsonify({'message': '题目不存在或无权限查看'}), 404

    # 3. 查询关联知识点（按类型分组）
    kps = db.fecth_all(
        "SELECT title, description, knowledgepoint_type FROM knowledgepoint WHERE question_id = %s",
        (question_id,)
    )

    # 分类整理知识点
    knowledgepoints = {
        'itself': [],  # 本题知识点
        'related': []  # 拓展知识点
    }
    for kp in kps:
        kp_type = kp[2]
        knowledgepoints[kp_type].append({
            'title': kp[0],
            'description': kp[1]
        })

    # 4. 构建返回数据（处理空值）
    return jsonify({
        'content': question[0],
        'userAnswer': question[1] or '未记录',
        'correctAnswer': question[2] or '未记录',
        'errorReason': question[3] or '无',
        'knowledgepoints': knowledgepoints
    }), 200



# 单道错题删除接口
@qc.route('/deletequestion_singal', methods=['POST'])
def deletequestion_singal():

    # 1. 获取并校验参数
    data = request.get_json()
    question_id = data.get("question_id")
    if not question_id:
        return jsonify({'message': '缺少必需参数question_id'}), 400

    # 2. 执行删除操作（假设db.execute会返回影响行数）
    affected_rows = db.execute("DELETE FROM question WHERE id = %s", (question_id,))
    
    # 3. 处理删除结果
    if affected_rows == 0:
        return jsonify({'message': '未找到对应错题或已删除'}), 404
    
    # 4. 级联删除关联的知识点（可选，根据业务需求）
    db.execute("DELETE FROM knowledgepoint WHERE question_id = %s", (question_id,))
    
    return jsonify({'message': '错题删除成功'}), 200

    