from utils import db
from flask import Blueprint, request, jsonify, session, render_template
import hashlib


ac = Blueprint("account", __name__)



#注册接口
@ac.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    # 检查用户名和密码是否为空
    if not username or not password:
        return jsonify({'message': '用户名和密码不能为空'}), 400

    #检查用户名是否存在
    user = db.fecth_one("SELECT * FROM users WHERE username = %s", (username,))
    if user:
            return jsonify({'message': '用户名已存在'}), 400
    
    # 对密码进行哈希处理
    hashed_password = hashlib.sha256(password.encode()).hexdigest()

    # 创建新用户
    db.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, hashed_password))
    return jsonify({'message': '注册成功'}), 201




#登录接口
@ac.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    # 检查用户名和密码是否为空
    if not username or not password:
        return jsonify({'message': '用户名和密码不能为空'}), 400
    
    # 对密码进行哈希处理
    hashed_password = hashlib.sha256(password.encode()).hexdigest()

    #查询用户
    user = db.fecth_one("SELECT * FROM users WHERE username = %s AND password = %s", (username, hashed_password))
    id = db.fecth_one("SELECT id FROM users WHERE username = %s AND password = %s", (username, hashed_password))
    if user:
        session['username'] = username
        session['user_id'] = id[0]
        return jsonify({'message': '登录成功'}), 200
    else:
        return jsonify({'message': '用户名或密码错误'}), 401


    
# 修改密码接口
@ac.route('/change_password', methods=['POST'])
def change_password():
    if 'username' not in session:
        return jsonify({'message': '未登录'}), 401

    data = request.get_json()
    old_password = data.get('old_password')
    new_password = data.get('new_password')

    #检查输入密码是否为空
    if not old_password or not new_password:
        return jsonify({'message': '原密码和新密码不能为空'}), 400

    username = session['username']
    old_hashed_password = hashlib.sha256(old_password.encode()).hexdigest()

    # 验证原密码
    user = db.fecth_one("SELECT * FROM users WHERE username = %s AND password = %s", (username, old_hashed_password))
    if not user:
            return jsonify({'message': '原密码错误'}), 400
    
    #更新密码
    new_hashed_password = hashlib.sha256(new_password.encode()).hexdigest()
    db.execute("UPDATE users SET password = %s WHERE username = %s", (new_hashed_password, username))
    return jsonify({'message': '密码修改成功'}), 200



# 注销账户接口
@ac.route('/delete_account', methods=['POST'])
def delete_account():
    if 'username' not in session:
        return jsonify({'message': '未登录'}), 401

    username = session['username']

    db.execute("DELETE FROM users WHERE username = %s", (username,))
    session.pop('username', None)
    return jsonify({'message': '账户注销成功'}), 200