import mysql.connector

db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'xx100200',
    'database': 'ai_errorbook'
}

#测试数据库连接
def test_db_connection():
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        result = cursor.fetchone()
        cursor.close()
        conn.close()
        return True
    except mysql.connector.Error as err:
        print(f"数据库连接错误: {err}")
        return False


#查询单个
def fecth_one(sql, params):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(buffered=True)
    cursor.execute(sql, params)
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result

#查询全部
def fecth_all(sql, params):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(buffered=True)
    cursor.execute(sql, params)
    result = cursor.fetchall()
    cursor.close()
    conn.close()
    return result

#创建
def execute(sql, params):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute(sql, params)
    conn.commit()
    cursor.close()
    conn.close()

# 封装事务操作
def transaction_execute(operations):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        conn.start_transaction()

        for sql, params in operations:
            cursor.execute(sql, params)

        conn.commit()
        return True
    except Exception as e:
        if conn.is_connected():
            conn.rollback()
        print(f"事务执行出错: {e}")
        return False
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()