class KnowledgePoint:
    def __init__(self, kpId, title, description):
        self.kpId = kpId
        self.title = title
        self.description = description
        
    def show_details(self):
        return f"{self.kpId}.{self.title}\n{self.description}"