class LearningPlan:
    def __init__(self, title: str, suggestions: list, daily_tasks: list):
        self.title = title
        self.suggestions = suggestions
        self.daily_tasks = daily_tasks
        
    def show_details(self) -> str:
        result = f"学习计划标题：{self.title}\n"
        result += "建议学习步骤：\n"
        for i, suggestion in enumerate(self.suggestions, 1):
            result += f"{i}. {suggestion}\n"
        result += "\n每日任务：\n"
        for task in self.daily_tasks:
            result += f"- {task}\n"
        return result