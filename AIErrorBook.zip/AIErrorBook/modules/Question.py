class Question:
    def __init__(self, subject,questionId, content, userAnswer, correctAnswer, errorReason):
        self.subject = subject
        self.questionId = questionId
        self.content = content
        self.userAnswer = userAnswer
        self.correctAnswer = correctAnswer
        self.errorReason = errorReason
        self.knowledgepoint = []
        self.relatedknowledgepoint = []
        
    def updateKnowledgePoint(self, kp):
        self.knowledgepoint = kp
        
    def updateRelatedKnowledgePoint(self, kp):
        self.relatedknowledgepoint = kp
        
    def show_details(self):
        result = f"科目:{self.subject}\n"
        result += f"{self.questionId}:{self.content}\n"
        result += f"你的答案:{self.userAnswer}\n"
        result += f"正确答案:{self.correctAnswer}\n"
        result += f"错因分析:{self.errorReason}\n"
        result += "本题知识点:\n"
        for kp in self.knowledgepoint:
            result += kp.show_details() + "\n"
        result += "相关知识点:\n"
        for kp in self.relatedknowledgepoint:
            result += kp.show_details() + "\n"
        return result