from typing import List
class Exercise:
    def __init__(self, exerciseId: int, content: str, difficulty: int, correctAnswer: str):
        self.exerciseId = exerciseId
        self.content = content
        self.difficulty = difficulty
        self.correctAnswer = correctAnswer
        
    def getExercisePreview(self) -> str:
        result = f"{self.exerciseId}. {self.content}\n"
        result += f"难度：{'★' * self.difficulty}\n"
        result += f"答案：{self.correctAnswer}\n"        
        return result